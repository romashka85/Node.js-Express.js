const mongoose = require('mongoose');

module.exports = () => {
 //TODO:
}